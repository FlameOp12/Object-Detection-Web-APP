from fastapi import FastAPI, UploadFile, WebSocket
from fastapi.responses import StreamingResponse
import cv2
from ultralytics import YOLO
import numpy as np

app = FastAPI()

# Load the YOLO model
model = YOLO("yolov8n.pt")

# Flag to control detection
is_detecting = False

@app.get("/")
def home():
    return {"message": "YOLO Object Detection API"}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    global is_detecting
    await websocket.accept()

    # Open the webcam
    cap = cv2.VideoCapture(0)
    try:
        while True:
            if not is_detecting:
                await websocket.receive_text()  # Wait for a "START" message
                is_detecting = True

            ret, frame = cap.read()
            if not ret:
                break

            # Perform detection
            results = model.predict(source=frame, save=False, imgsz=640)
            annotated_frame = results[0].plot()

            # Encode frame to send via WebSocket
            _, buffer = cv2.imencode('.jpg', annotated_frame)
            await websocket.send_bytes(buffer.tobytes())

    except Exception as e:
        print(f"WebSocket error: {e}")
    finally:
        cap.release()
        await websocket.close()
        is_detecting = False
