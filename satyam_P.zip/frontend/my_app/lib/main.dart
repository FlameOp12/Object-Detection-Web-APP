import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ObjectDetectionScreen(),
    );
  }
}

class ObjectDetectionScreen extends StatefulWidget {
  @override
  _ObjectDetectionScreenState createState() => _ObjectDetectionScreenState();
}

class _ObjectDetectionScreenState extends State<ObjectDetectionScreen> {
  final WebSocketChannel channel =
      WebSocketChannel.connect(Uri.parse('ws://localhost:8000/ws')); // Backend WebSocket endpoint
  bool isDetecting = false; // Toggle for detection state
  Uint8List? frameBytes; // To hold frame data received from backend

  // Toggle detection and send START/STOP messages to backend
  void toggleDetection() {
    if (isDetecting) {
      channel.sink.add('STOP'); // Send STOP command
    } else {
      channel.sink.add('START'); // Send START command
    }
    setState(() {
      isDetecting = !isDetecting;
    });
  }

  @override
  void initState() {
    super.initState();
    // Listen for data from backend
    channel.stream.listen((data) {
      setState(() {
        frameBytes = data; // Update frame with received data
      });
    });
  }

  @override
  void dispose() {
    channel.sink.close(); // Close WebSocket connection
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("YOLO Object Detection"),
        backgroundColor: Colors.blue,
      ),
      body: Column(
        children: [
          // Display the camera feed with detection or a placeholder
          Expanded(
            child: frameBytes != null
                ? Image.memory(frameBytes!) // Show the live detection feed
                : const Center(
                    child: Text(
                      "No detection running",
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
          ),
          // Button to toggle detection
          ElevatedButton(
            onPressed: toggleDetection,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
            ),
            child: Text(
              isDetecting ? "STOP DETECTION" : "START DETECTION",
              style: const TextStyle(fontSize: 18),
            ),
          ),
        ],
      ),
    );
  }
}
